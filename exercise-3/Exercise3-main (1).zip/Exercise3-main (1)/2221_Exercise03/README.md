# Exercise3
CNN
